# Smart Home Automation

A Raspberry Pi-based system for home automation, including smart sensors, automation scripts, and a web dashboard.